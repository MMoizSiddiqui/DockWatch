DockWatch for Linux (x86_64)
============================
Start:            ./start-dockwatch
                  (first time: downloads and verifies the scanners, about a minute)
                  then open http://127.0.0.1:8765/ if your browser does not open by itself
Open a project:   paste the folder's full path on the Home page, or ./start-dockwatch /path/to/project
Stop:             Ctrl+C in the terminal
Command line:     ./dockwatch-engine scan /path/to/project --gate --pdf report.pdf
                  ./dockwatch-engine --help
Needs:            64-bit Linux with glibc 2.31 or newer (Ubuntu 20.04+, Debian 11+, Fedora, RHEL/Rocky 9+)
                  Docker only for the optional image scanners; git only for the git timeline
Data:             ~/.local/share/dockwatch (scanners, recent projects, scan timings)
Guide:            https://github.com/MMoizSiddiqui/DockWatch
